/*
* fan.c : 
*	Fonctions : 
*		d_open : appelée lors de l'ouverture du fichier virtuel lié au module
*		d_release : appelée lors de la fermeture du fichier virtuel lié au module
*		d_read : appelée lors de la lecture du fichier virtuel lié au module
*		d_write : appelée lors de l'écriture dans le fichier virtuel lié au module
*		fonctionInit : appelée lors du chargement du module, gère les initialisations
*		fonctionExit : appelée lors du déchargement du module, gère les libérations de mémoire
*/
#include <stdio.h>
#include <unistd.h>

int main(void)
{
    int status;
    FILE *fdServo, *fdStick;
    int buffer[50];
    
    fdServo = fopen("/dev/servo","w");
    fdStick = fopen("/dev/stick","r");
    
    if(!fdServo)
    {
        printf("Erreur ouverture fdServo\n");
        return fdServo;
    }
    
    if(!fdStick)
    {
        printf("Erreur ouverture fdStick\n");
        fclose(fdServo);
        return fdStick;
    }
    

    while(1)
    {
        status = fread(buffer,sizeof(int),1,fdStick);
        if(status < 0)
        {
            printf("Erreur lecture fread\n");
            fclose(fdServo);
            fclose(fdStick);
            return status;
        }
        printf("Buffer : |%d|\n",buffer[0]);
        //Traduction et envoi de la valeur du stick sous forme d'angle entre -90 et 90
        //angle = angle+10
        fprintf(fdServo,"%d",buffer[0]);
        fflush(fdServo);
        printf("Lu : %d\n",status);
        usleep(100000);
    }
    
    return 0;
}
